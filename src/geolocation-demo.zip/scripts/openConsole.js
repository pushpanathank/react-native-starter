import { companyToken } from '../components/consoleConfig';
import opn from 'opn'
opn(`http://bg-console.herokuapp.com/#${companyToken}`);
