#!/bin/sh

adb shell cmd jobscheduler run -f com.transistorsoft.backgroundgeolocation.react 999


