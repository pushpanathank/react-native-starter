#!/bin/sh

adb install -r android/app/build/outputs/apk/release/app-release.apk
