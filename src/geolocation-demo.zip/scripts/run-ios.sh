open -a Xcode ios/RNBackgroundGeolocationSample.xcodeproj
