const ENV = {
	TRACKER_HOST: 'http://tracker.transistorsoft.com'
};

export default ENV;